<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 20px ">
    <center><h2><b>Inventaris Sekolah</b></h2></center><br><br><br>
    <?php $__currentLoopData = $cruds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="<?php echo e(route('crud.update', $c['kode_barang'])); ?>" method="POST" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" placeholder="nama" name="old_name" value="<?php echo e($c['nama_barang']); ?>">
        <div class="form-group"> 
        <label>Kode Barang :</label>
        <input type="text" class="form-control" placeholder="Kode Barang" name="kode_barang" value="<?php echo e($c['kode_barang']); ?>" required>
        <div class="invalid-feedback">
        Harap masukkan Kode Barang.
        </div>
        </div>
        <div class="form-group"> 
        <label>Nama Barang :</label>
        <input type="text" class="form-control" placeholder="Nama barang" name="name" value="<?php echo e($c['nama_barang']); ?>" required>
        <div class="invalid-feedback">
        Harap masukkan Nama Barang.
        </div>
        </div>
        <div class="form-group"> 
        <label>Kategori :</label>
        <input type="text" class="form-control" placeholder="Kategori" name="kategori" value="<?php echo e($c['kategori']); ?>" required>  
        <div class="invalid-feedback">
        Harap masukkan Kategori.
        </div>
        </div>
        <input type="submit" class="btn btn-warning" value="Edit Data">
        <a href="/crud" class="btn btn-outline-warning">Kembali</a>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- JS Validasi -->
<script>
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>

</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris\resources\views/edit.blade.php ENDPATH**/ ?>